package uz.najottalim.ekzamen.models;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

import javax.persistence.*;
import javax.persistence.GenerationType;
import java.time.LocalDateTime;

@Entity
@Table(name = "timesheets")
@Data
@AllArgsConstructor
@NoArgsConstructor

@FieldDefaults(level = AccessLevel.PRIVATE)
public class TimeSheet {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;


    LocalDateTime checkInTime;

    LocalDateTime checkOutTime;

    @ManyToOne
    @JoinColumn(name = "employee_id")
    Employee employee;

}