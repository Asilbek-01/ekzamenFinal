package uz.najottalim.ekzamen;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EkzamenApp {

	public static void main(String[] args) {
		SpringApplication.run(EkzamenApp.class, args);
	}

}
