package uz.najottalim.ekzamen.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import uz.najottalim.ekzamen.models.TimeSheet;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface TimeSheetRepository extends JpaRepository<TimeSheet, Long> {

    List<TimeSheet> findByEmployeeId(Long employeeId);

    List<TimeSheet> findAllByCheckInTimeBetween(LocalDateTime localDateTime, LocalDateTime localDateTime1);

    List<TimeSheet> findByEmployeeIdAndCheckInTimeBetween(Long id, LocalDateTime localDateTime, LocalDateTime localDateTime1);
}
