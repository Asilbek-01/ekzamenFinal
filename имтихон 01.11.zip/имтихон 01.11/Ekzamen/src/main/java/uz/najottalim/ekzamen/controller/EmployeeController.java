package uz.najottalim.ekzamen.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import uz.najottalim.ekzamen.models.Employee;
import uz.najottalim.ekzamen.services.EmployeeService;

import java.util.List;
import java.util.Map;

@RestController
@RequiredArgsConstructor
@RequestMapping("/employees")
public class EmployeeController {

    private final EmployeeService employeeService;


    @GetMapping
    public ResponseEntity<List<Employee>> getAllEmployees() {
        List<Employee> employees = employeeService.getAllEmployees();
        return ResponseEntity.ok(employees);
    }

    @GetMapping("/{Id}")
    public ResponseEntity<Employee> getEmployeeById(@PathVariable Long Id) {
        Employee employee;
        employee = employeeService.getEmployeeById(Id);
        if (employee != null) {
            return ResponseEntity.ok(employee);
        }
        return ResponseEntity.notFound().build();
    }

    @PostMapping("/saveEmployee")
    public ResponseEntity<Void> saveEmployee(@RequestBody Employee employee) {
        employeeService.saveEmployee(employee);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteEmployee(@PathVariable Long id) {
        employeeService.deleteEmployee(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{id}/monthly-salary")
    public ResponseEntity<Double> calculateMonthlySalary(@PathVariable Long id) {
        Double monthlySalary;
        monthlySalary = employeeService.calculateMonthlySalary(id);
        return ResponseEntity.ok(monthlySalary);
    }

    @GetMapping("/monthly-statistics")
    public ResponseEntity<Map<String, Integer>> getMonthlyStatistics() {
        Map<String, Integer> monthlyStatistics = employeeService.getMonthlyStatistics();
        return ResponseEntity.ok(monthlyStatistics);
    }

    @GetMapping("/daily-statistics")
    public ResponseEntity<Map<String, Integer>> getDailyStatistics() {
        Map<String, Integer> dailyStatistics = employeeService.getDailyStatistics();
        return ResponseEntity.ok(dailyStatistics);
    }

    @GetMapping("/worked-employees-in-month")
    public ResponseEntity<List<Map<String, Object>>> getWorkedEmployeesInMonth() {
        List<Map<String, Object>> workedEmployees = employeeService.getWorkedEmployeesInMonth();
        return ResponseEntity.ok(workedEmployees);
    }

    @GetMapping("/lateEmployees")
    public ResponseEntity<List<Map<String, Object>>> getLateEmployees() {
        List<Map<String, Object>> lateEmployees = employeeService.getLateEmployees();
        return ResponseEntity.ok(lateEmployees);
    }



}