package uz.najottalim.ekzamen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EkzamenAppTests {

	@Test
	void contextLoads() {
	}

}
